"""
resolution.py
--------------
A simplified, understandable demonstration of resolution refutation for
one FOL rule:

    Rule (implication form):   LowMark(X, S) -> RemedialClass(X, S)
    Clause form:                ~LowMark(X, S) v RemedialClass(X, S)

To prove RemedialClass(student, subject) by resolution/refutation:
  1. Negate the goal:            ~RemedialClass(student, subject)
  2. Resolve the rule clause with the negated goal (unifying X=student,
     S=subject). This cancels RemedialClass, leaving:
                                  ~LowMark(student, subject)
  3. Resolve that with the known fact clause LowMark(student, subject).
     The two complementary literals cancel, producing the EMPTY CLAUSE.
  4. An empty clause means the negated goal led to a contradiction, so
     the original goal RemedialClass(student, subject) must be TRUE.

The subject used is picked dynamically from the student's actual facts
(a real LowMark fact from the knowledge base) - nothing is hard-coded.
"""

from .knowledge_base import get_student_facts, fact_str


def demonstrate_resolution(student_name):
    facts = get_student_facts(student_name)
    low_marks = sorted(f for f in facts if f[0] == "lowMark")
    if not low_marks:
        return None

    fact = low_marks[0]
    subject = fact[2]

    query = f"RemedialClass({student_name}, {subject})"
    negated_query = f"\u00acRemedialClass({student_name}, {subject})"
    fact_clause = fact_str(fact)

    steps = [
        (
            f"Step 1 - Convert the rule to clause form: "
            f"\u00acLowMark(X, S) \u2228 RemedialClass(X, S)"
        ),
        (
            f"Step 2 - Negate the query and add it as a clause: {negated_query}"
        ),
        (
            f"Step 3 - Resolve the rule clause with the negated query, "
            f"unifying X = {student_name}, S = {subject}. "
            f"The literal RemedialClass({student_name}, {subject}) cancels with "
            f"its negation, leaving the resolvent: \u00acLowMark({student_name}, {subject})"
        ),
        (
            f"Step 4 - Resolve \u00acLowMark({student_name}, {subject}) with the known "
            f"fact clause {fact_clause}. The two complementary literals cancel, "
            f"producing the EMPTY CLAUSE."
        ),
        (
            f"Step 5 - An empty clause means assuming the negated query leads to a "
            f"contradiction. Therefore the original query {query} is TRUE."
        ),
    ]

    return {
        "used_student": student_name,
        "subject": subject,
        "rule_fol": "\u2200x\u2200s ( LowMark(x, s) \u2192 RemedialClass(x, s) )",
        "clause_form": "\u00acLowMark(X, S) \u2228 RemedialClass(X, S)",
        "query": query,
        "negated_query": negated_query,
        "fact_clause": fact_clause,
        "steps": steps,
        "conclusion": f"{query} = TRUE",
    }
