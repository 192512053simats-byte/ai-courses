"""
rules.py
--------
The FOL rule base for the advisory agent. Each rule is written as a
Python dictionary containing:

    name        - short id (R1, R2, ...)
    fol         - the rule written in First-Order Logic notation
    premises    - list of pattern tuples (the "if" part / antecedent)
    conclusion  - a single pattern tuple (the "then" part / consequent)
    description - plain-English explanation

Rules use the variables X and S (at least 2 variables, as required),
and are universally quantified over all students/subjects (they apply
to ANY x, s that satisfy the premises - true First-Order generalization,
not facts hard-coded to one student name).
"""

RULES = [
    {
        "name": "R1",
        "fol": "\u2200x ( LowAttendance(x) \u2192 ImproveAttendance(x) )",
        "premises": [("lowAttendance", "X")],
        "conclusion": ("improveAttendance", "X"),
        "description": (
            "If a student's attendance is below the required level, "
            "recommend improving attendance."
        ),
    },
    {
        "name": "R2",
        "fol": "\u2200x\u2200s ( LowMark(x, s) \u2192 RemedialClass(x, s) )",
        "premises": [("lowMark", "X", "S")],
        "conclusion": ("remedialClass", "X", "S"),
        "description": (
            "If a student has a low mark in some subject, recommend a "
            "remedial class for that subject."
        ),
    },
    {
        "name": "R3",
        "fol": "\u2200x\u2200s ( AssignmentPending(x, s) \u2192 CompleteAssignment(x, s) )",
        "premises": [("assignmentPending", "X", "S")],
        "conclusion": ("completeAssignment", "X", "S"),
        "description": (
            "If a student has a pending assignment in some subject, "
            "recommend completing it."
        ),
    },
    {
        "name": "R4",
        "fol": "\u2200x\u2200s ( ( LowMark(x, s) \u2227 LowAttendance(x) ) \u2192 NeedsAcademicSupport(x) )",
        "premises": [("lowMark", "X", "S"), ("lowAttendance", "X")],
        "conclusion": ("needsAcademicSupport", "X"),
        "description": (
            "If a student has both a low mark in some subject AND low "
            "attendance, then the student needs academic support."
        ),
    },
    {
        "name": "R5",
        "fol": "\u2200x ( NeedsAcademicSupport(x) \u2192 MeetFacultyAdvisor(x) )",
        "premises": [("needsAcademicSupport", "X")],
        "conclusion": ("meetFacultyAdvisor", "X"),
        "description": (
            "If a student needs academic support, recommend meeting the "
            "faculty advisor."
        ),
    },
    {
        "name": "R6",
        "fol": "\u2200x\u2200s ( ( StrongProgrammer(x) \u2227 GoodMark(x, s) ) \u2192 RecommendAdvancedLearning(x) )",
        "premises": [("strongProgrammer", "X"), ("goodMark", "X", "S")],
        "conclusion": ("recommendAdvancedLearning", "X"),
        "description": (
            "If a student is a strong programmer AND has a good mark in "
            "some subject, recommend advanced learning activities."
        ),
    },
    {
        "name": "R7",
        "fol": "\u2200x ( Student(x) \u2192 AcademicEntity(x) )",
        "premises": [("student", "X")],
        "conclusion": ("academicEntity", "X"),
        "description": (
            "Every student is, by definition, an academic entity "
            "(a simple universally quantified fact used for illustration)."
        ),
    },
]

# Recommendation text templates keyed by the inferred predicate. The
# template is formatted against the full fact tuple, e.g. for the fact
# ('remedialClass', 'Alice', 'Mathematics'): {0}=predicate, {1}=student,
# {2}=subject.
RECOMMENDATION_TEMPLATES = {
    "improveAttendance": "Improve attendance",
    "remedialClass": "Attend remedial class in {2}",
    "completeAssignment": "Complete pending assignment in {2}",
    "meetFacultyAdvisor": "Meet faculty advisor",
    "recommendAdvancedLearning": "Join advanced learning activities",
}

# Quantifier examples shown in the UI
UNIVERSAL_EXAMPLE = "\u2200x ( Student(x) \u2192 AcademicEntity(x) )"
EXISTENTIAL_EXAMPLE = "\u2203x ( Student(x) \u2227 NeedsAcademicSupport(x) )"
