"""
unification.py
---------------
Implements simple FOL unification: matching a rule pattern (which contains
variables) against a concrete fact, and producing a substitution that makes
them identical.

Variables in this project are always written as short uppercase tokens:
X, Y, S, T, Z (e.g. the rule pattern ('lowMark', 'X', 'S')). Everything
else (student names, subjects, numbers) is treated as a constant.
"""

VARIABLES = {"X", "Y", "S", "T", "Z"}


def is_var(term):
    """A term is a variable if it is one of our reserved variable tokens."""
    return term in VARIABLES


def unify(pattern, fact, subst=None):
    """
    Try to unify a pattern tuple (may contain variables) with a fact tuple
    (all constants). Returns a substitution dict {var: value} on success,
    or None if unification fails.
    """
    if subst is None:
        subst = {}
    if len(pattern) != len(fact):
        return None

    new_subst = dict(subst)
    for p_term, f_term in zip(pattern, fact):
        if is_var(p_term):
            if p_term in new_subst:
                if new_subst[p_term] != f_term:
                    return None  # already bound to something else
            else:
                new_subst[p_term] = f_term
        else:
            if p_term != f_term:
                return None  # constants must match exactly
    return new_subst


def substitute(pattern, subst):
    """Apply a substitution to a pattern, replacing bound variables."""
    return tuple(subst.get(term, term) for term in pattern)


def has_vars(pattern):
    """True if the pattern still contains at least one unbound variable."""
    return any(is_var(term) for term in pattern)


def demonstrate_unification(student_name=None):
    """
    Build a step-by-step unification example using a real LowMark fact
    from the knowledge base, unified against the rule pattern
    LowMark(X, S) -> RemedialClass(X, S).
    """
    from .knowledge_base import ALL_FACTS, fact_str

    low_marks = sorted(f for f in ALL_FACTS if f[0] == "lowMark")
    if not low_marks:
        return None

    fact = None
    if student_name:
        for f in low_marks:
            if f[1] == student_name:
                fact = f
                break
    if fact is None:
        fact = low_marks[0]

    pattern = ("lowMark", "X", "S")
    steps = []
    subst = {}
    for p_term, f_term in zip(pattern, fact):
        if is_var(p_term):
            steps.append(f"{p_term} is a variable -> bind {p_term} = {f_term}")
            subst[p_term] = f_term
        else:
            steps.append(f"'{p_term}' matches '{f_term}' directly (same predicate name)")

    conclusion_pattern = ("remedialClass", "X", "S")
    conclusion = substitute(conclusion_pattern, subst)

    return {
        "used_student": fact[1],
        "rule_pattern": "LowMark(X, S)  ->  RemedialClass(X, S)",
        "fact": fact_str(fact),
        "steps": steps,
        "substitution": subst,
        "conclusion": fact_str(conclusion),
    }
