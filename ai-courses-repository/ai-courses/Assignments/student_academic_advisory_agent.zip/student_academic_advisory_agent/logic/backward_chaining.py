"""
backward_chaining.py
---------------------
A small backward-chaining ("goal-driven") inference engine.

To prove a goal fact:
  1. If the goal is already a known fact, it is proved directly.
  2. Otherwise, look for a rule whose CONCLUSION unifies with the goal.
     Recursively try to prove every premise of that rule (substituting in
     any bindings discovered so far). If a premise still contains a free
     variable after substitution, search the known facts for a value that
     satisfies it (this represents the existential search needed for
     variables like the subject S).
  3. If every premise can be proved, the goal is proved TRUE via that rule.

Every step is recorded into a trace list so the UI can show the full
reasoning tree.
"""

from .rules import RULES
from .unification import unify, substitute, has_vars
from .knowledge_base import fact_str


def _trace(trace, depth, text, kind):
    trace.append({"depth": depth, "text": text, "type": kind})


def prove(goal, facts, trace, depth=0):
    # Step 1: is the goal already a known (given) fact?
    if goal in facts:
        _trace(trace, depth, f"Fact found in knowledge base: {fact_str(goal)}", "fact")
        return True

    # Step 2: try every rule whose conclusion could produce this goal
    for rule in RULES:
        subst = unify(rule["conclusion"], goal)
        if subst is None:
            continue

        _trace(
            trace, depth,
            f"Goal {fact_str(goal)} matches the conclusion of rule {rule['name']}: {rule['fol']}",
            "rule",
        )

        current = dict(subst)
        rule_ok = True

        for premise in rule["premises"]:
            p_inst = substitute(premise, current)

            # If the premise still has a free variable (e.g. subject S),
            # search the facts for a value that satisfies it.
            if has_vars(p_inst):
                found = False
                for f in facts:
                    if f[0] != p_inst[0]:
                        continue
                    s2 = unify(p_inst, f, current)
                    if s2 is not None:
                        current = s2
                        p_inst = substitute(p_inst, s2)
                        found = True
                        break
                if not found:
                    _trace(trace, depth + 1, f"No fact satisfies sub-goal {fact_str(p_inst)}", "fail")
                    rule_ok = False
                    break

            _trace(trace, depth + 1, f"Sub-goal: prove {fact_str(p_inst)}", "subgoal")
            if not prove(p_inst, facts, trace, depth + 2):
                rule_ok = False
                break

        if rule_ok:
            _trace(trace, depth, f"=> {fact_str(goal)} is TRUE (proved via rule {rule['name']})", "success")
            return True
        else:
            _trace(trace, depth, f"Rule {rule['name']} could not be fully satisfied for {fact_str(goal)}", "rulefail")

    _trace(trace, depth, f"Could not prove {fact_str(goal)} -> FALSE", "fail")
    return False


def backward_chain(goal, facts):
    """Prove `goal` against `facts`. Returns (result_bool, trace_list)."""
    trace = []
    result = prove(goal, facts, trace)
    return result, trace
