"""
knowledge_base.py
------------------
This module defines the First-Order Logic (FOL) Knowledge Base for the
Intelligent Student Academic Advisory Agent.

Facts are represented as simple Python tuples, the same way a Prolog-style
FOL fact is written:

    ('lowAttendance', 'Alice')          -->  LowAttendance(Alice)
    ('examMark', 'Alice', 'Mathematics', 48)  -->  ExamMark(Alice, Mathematics, 48)

Every predicate's first argument (after the predicate name) is always the
student, which is why we can filter facts belonging to one student simply
by checking fact[1] == student_name.

Raw numeric data (attendance %, exam marks, etc.) is "grounded" into
symbolic base facts (LowAttendance, LowMark, GoodMark, StrongProgrammer ...)
using simple threshold checks. These grounded facts are what the FOL rules
(see rules.py) actually reason over using unification.
"""

# ---------------------------------------------------------------------------
# Thresholds used to ground raw numeric data into symbolic FOL facts
# ---------------------------------------------------------------------------
THRESHOLDS = {
    "attendance_required": 75,   # attendance %, below this -> LowAttendance
    "low_mark": 50,              # exam mark below this -> LowMark
    "good_mark": 75,             # exam mark at/above this -> GoodMark
}

# ---------------------------------------------------------------------------
# Raw student data (this is the only place "real world" numbers live)
# ---------------------------------------------------------------------------
STUDENTS_RAW = {
    "Alice": {
        "attendance": 65,
        "exam_marks": {"Mathematics": 48, "Physics": 82, "Chemistry": 70},
        "assignments_pending": ["AI"],
        "programming_skill": "average",
    },
    "Bob": {
        "attendance": 90,
        "exam_marks": {"Mathematics": 85, "Physics": 78, "Chemistry": 74},
        "assignments_pending": [],
        "programming_skill": "strong",
    },
    "Carol": {
        "attendance": 70,
        "exam_marks": {"English": 45, "Mathematics": 60, "Physics": 55},
        "assignments_pending": ["DBMS", "OS"],
        "programming_skill": "weak",
    },
    "David": {
        "attendance": 95,
        "exam_marks": {"Programming": 92, "Mathematics": 55, "Chemistry": 68},
        "assignments_pending": [],
        "programming_skill": "strong",
    },
}


def _build_facts():
    """Convert STUDENTS_RAW into a set of grounded FOL base facts."""
    facts = set()
    for name, data in STUDENTS_RAW.items():
        facts.add(("student", name))

        attendance = data["attendance"]
        facts.add(("attendance", name, attendance))
        if attendance < THRESHOLDS["attendance_required"]:
            facts.add(("lowAttendance", name))

        for subject, mark in data["exam_marks"].items():
            facts.add(("examMark", name, subject, mark))
            if mark < THRESHOLDS["low_mark"]:
                facts.add(("lowMark", name, subject))
            if mark >= THRESHOLDS["good_mark"]:
                facts.add(("goodMark", name, subject))

        for subject in data["assignments_pending"]:
            facts.add(("assignmentPending", name, subject))

        skill = data["programming_skill"]
        facts.add(("programmingSkill", name, skill))
        if skill == "strong":
            facts.add(("strongProgrammer", name))

    return facts


# The full, grounded FOL knowledge base (all students, all base facts)
ALL_FACTS = _build_facts()


def get_student_names():
    """Return the list of all student names in the knowledge base."""
    return sorted(STUDENTS_RAW.keys())


def get_student_facts(name):
    """Return the subset of base facts that belong to a given student."""
    return {f for f in ALL_FACTS if len(f) > 1 and f[1] == name}


def fact_str(fact):
    """Pretty-print a fact tuple in FOL notation, e.g. LowMark(Alice, Mathematics)."""
    if not fact:
        return ""
    pred = fact[0]
    pred_name = pred[0].upper() + pred[1:]
    args = ", ".join(str(a) for a in fact[1:])
    return f"{pred_name}({args})"
