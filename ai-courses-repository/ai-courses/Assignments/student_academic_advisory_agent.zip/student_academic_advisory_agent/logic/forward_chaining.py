"""
forward_chaining.py
--------------------
A small, general forward-chaining inference engine.

Starting from a set of known facts, it repeatedly tries every rule in the
rule base. Whenever ALL premises of a rule can be satisfied (via
unification) by facts that are already known, the rule "fires" and its
conclusion (after applying the substitution) is added as a new fact.
This repeats until no new facts can be derived (fixed point) - this is
data-driven ("bottom-up") reasoning.
"""

from .rules import RULES, RECOMMENDATION_TEMPLATES
from .unification import unify, substitute
from .knowledge_base import fact_str


def _find_substitutions(premises, facts):
    """
    Find every substitution that satisfies ALL premises simultaneously
    against the known facts (a simple backtracking join).
    """
    results = [{}]
    for premise in premises:
        new_results = []
        for subst in results:
            p_inst = substitute(premise, subst)
            for f in facts:
                if f[0] != p_inst[0]:
                    continue
                s2 = unify(p_inst, f, subst)
                if s2 is not None:
                    new_results.append(s2)
        results = new_results
        if not results:
            break
    return results


def run_forward_chaining(initial_facts):
    """
    Run forward chaining starting from `initial_facts` (a set of fact
    tuples). Returns (final_facts_set, steps_list) where steps_list
    records every rule firing in order, for display in the UI.
    """
    facts = set(initial_facts)
    steps = []
    iteration = 1
    changed = True

    while changed:
        changed = False
        for rule in RULES:
            substs = _find_substitutions(rule["premises"], facts)
            for subst in substs:
                concl = substitute(rule["conclusion"], subst)
                if concl not in facts:
                    facts.add(concl)
                    steps.append({
                        "iteration": iteration,
                        "rule": rule["name"],
                        "rule_fol": rule["fol"],
                        "premises_used": [fact_str(substitute(p, subst)) for p in rule["premises"]],
                        "substitution": {k: v for k, v in subst.items()},
                        "new_fact": fact_str(concl),
                    })
                    changed = True
        iteration += 1

    return facts, steps


def derive_recommendations(facts, student_name):
    """Turn inferred facts about a student into plain-English recommendations."""
    recs = []
    for f in facts:
        if f[0] in RECOMMENDATION_TEMPLATES and len(f) > 1 and f[1] == student_name:
            recs.append(RECOMMENDATION_TEMPLATES[f[0]].format(*f))
    return sorted(set(recs))


def analyze_student(student_name, student_facts):
    """Run forward chaining for one student and build a full analysis result."""
    final_facts, steps = run_forward_chaining(student_facts)
    recommendations = derive_recommendations(final_facts, student_name)
    return {
        "name": student_name,
        "initial_facts": sorted(fact_str(f) for f in student_facts),
        "steps": steps,
        "final_facts": sorted(fact_str(f) for f in final_facts),
        "recommendations": recommendations,
    }
