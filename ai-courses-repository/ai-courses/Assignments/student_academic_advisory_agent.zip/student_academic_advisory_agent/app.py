"""
app.py
------
Flask web application for the Intelligent Student Academic Advisory Agent.

This file only wires together HTTP routes with the reasoning engine that
lives in the `logic/` package. All First-Order Logic knowledge (facts,
rules) and reasoning algorithms (unification, forward chaining, backward
chaining, resolution) are implemented there - this file does not contain
any hard-coded recommendations.

Run with:
    python app.py
Then open:
    http://127.0.0.1:5000
"""

from flask import Flask, render_template, jsonify, request

from logic.knowledge_base import (
    STUDENTS_RAW,
    ALL_FACTS,
    THRESHOLDS,
    get_student_names,
    get_student_facts,
    fact_str,
)
from logic.rules import RULES, UNIVERSAL_EXAMPLE, EXISTENTIAL_EXAMPLE
from logic.forward_chaining import run_forward_chaining, analyze_student
from logic.backward_chaining import backward_chain
from logic.unification import demonstrate_unification
from logic.resolution import demonstrate_resolution

app = Flask(__name__)


# ---------------------------------------------------------------------------
# Page routes (render HTML templates)
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/advisory")
def advisory():
    return render_template("advisory.html", students=get_student_names())


@app.route("/knowledge")
def knowledge():
    facts_by_student = {
        name: sorted(fact_str(f) for f in get_student_facts(name))
        for name in get_student_names()
    }
    return render_template(
        "knowledge.html",
        facts_by_student=facts_by_student,
        thresholds=THRESHOLDS,
        total_facts=len(ALL_FACTS),
    )


@app.route("/rules")
def rules_page():
    # Evaluate the existential quantifier example live, over the whole KB
    final_facts, _ = run_forward_chaining(ALL_FACTS)
    support_students = sorted({f[1] for f in final_facts if f[0] == "needsAcademicSupport"})
    return render_template(
        "rules.html",
        rules=RULES,
        universal_example=UNIVERSAL_EXAMPLE,
        existential_example=EXISTENTIAL_EXAMPLE,
        support_students=support_students,
    )


@app.route("/queries")
def queries_page():
    return render_template("queries.html", students=get_student_names())


@app.route("/unification")
def unification_page():
    return render_template("unification.html", students=get_student_names())


@app.route("/forward")
def forward_page():
    return render_template("forward.html", students=get_student_names())


@app.route("/backward")
def backward_page():
    return render_template("backward.html", students=get_student_names())


@app.route("/resolution")
def resolution_page():
    return render_template("resolution.html", students=get_student_names())


@app.route("/comparison")
def comparison_page():
    return render_template("comparison.html")


# ---------------------------------------------------------------------------
# JSON API routes (used by static/script.js to actually run the reasoning)
# ---------------------------------------------------------------------------

@app.route("/api/student/<name>")
def api_student(name):
    if name not in STUDENTS_RAW:
        return jsonify({"error": "student not found"}), 404
    data = STUDENTS_RAW[name]
    facts = sorted(fact_str(f) for f in get_student_facts(name))
    return jsonify({
        "name": name,
        "attendance": data["attendance"],
        "exam_marks": data["exam_marks"],
        "assignments_pending": data["assignments_pending"],
        "programming_skill": data["programming_skill"],
        "facts": facts,
    })


@app.route("/api/analyze/<name>")
def api_analyze(name):
    if name not in STUDENTS_RAW:
        return jsonify({"error": "student not found"}), 404
    result = analyze_student(name, get_student_facts(name))
    return jsonify(result)


@app.route("/api/forward/<name>")
def api_forward(name):
    if name not in STUDENTS_RAW:
        return jsonify({"error": "student not found"}), 404
    student_facts = get_student_facts(name)
    final_facts, steps = run_forward_chaining(student_facts)
    return jsonify({
        "name": name,
        "initial_facts": sorted(fact_str(f) for f in student_facts),
        "steps": steps,
        "final_facts": sorted(fact_str(f) for f in final_facts),
    })


@app.route("/api/backward/<name>")
def api_backward(name):
    if name not in STUDENTS_RAW:
        return jsonify({"error": "student not found"}), 404
    facts = get_student_facts(name)
    goal = ("needsAcademicSupport", name)
    result, trace = backward_chain(goal, facts)
    return jsonify({"name": name, "goal": fact_str(goal), "result": result, "trace": trace})


@app.route("/api/unify/<name>")
def api_unify(name):
    demo = demonstrate_unification(name)
    if demo is None:
        return jsonify({"error": "no LowMark fact available for demonstration"}), 404
    return jsonify(demo)


@app.route("/api/resolution/<name>")
def api_resolution(name):
    if name not in STUDENTS_RAW:
        return jsonify({"error": "student not found"}), 404
    demo = demonstrate_resolution(name)
    if demo is not None:
        return jsonify(demo)

    # Fallback: this student has no LowMark fact, so pick a student who does
    # (still fully derived from the knowledge base, never hard-coded).
    for other in get_student_names():
        demo = demonstrate_resolution(other)
        if demo is not None:
            demo["note"] = (
                f"{name} currently has no subject below the low-mark threshold, "
                f"so this demonstration uses {other}'s data instead."
            )
            return jsonify(demo)

    return jsonify({"error": "no demonstration available"}), 404


@app.route("/api/query")
def api_query():
    """
    Handles the two required query-system questions:
      type=support  -> Does <student> need academic support?
      type=remedial -> Does <student> need a remedial class (in some subject)?
    Both require actual inference (backward chaining), not a stored fact.
    """
    student = request.args.get("student", "")
    qtype = request.args.get("type", "")

    if student not in STUDENTS_RAW:
        return jsonify({"error": "invalid student"}), 400

    facts = get_student_facts(student)

    if qtype == "support":
        goal = ("needsAcademicSupport", student)
        result, trace = backward_chain(goal, facts)
        return jsonify({
            "question": f"Does {student} need academic support?",
            "goal": fact_str(goal),
            "result": result,
            "trace": trace,
        })

    if qtype == "remedial":
        # Existential query: does there EXIST a subject S such that
        # RemedialClass(student, S) can be proved?
        subjects = sorted({f[2] for f in facts if f[0] == "examMark"})
        combined_trace = []
        result = False
        chosen_subject = None
        for subject in subjects:
            goal = ("remedialClass", student, subject)
            r, trace = backward_chain(goal, facts)
            combined_trace.append({
                "depth": 0,
                "text": f"--- Trying subject: {subject} ---",
                "type": "header",
            })
            combined_trace.extend(trace)
            if r:
                result = True
                chosen_subject = subject
                break
        display_goal = f"\u2203s RemedialClass({student}, s)"
        return jsonify({
            "question": f"Does {student} need a remedial class?",
            "goal": display_goal,
            "result": result,
            "chosen_subject": chosen_subject,
            "trace": combined_trace,
        })

    return jsonify({"error": "invalid query type"}), 400


if __name__ == "__main__":
    app.run(debug=True)
