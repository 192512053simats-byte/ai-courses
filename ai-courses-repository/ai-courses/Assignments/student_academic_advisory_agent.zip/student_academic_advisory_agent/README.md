# Intelligent Student Academic Advisory Agent (First-Order Logic)

A simple Flask web application that demonstrates First-Order Logic (FOL)
knowledge representation and reasoning: facts, universally/existentially
quantified rules, unification, forward chaining, backward chaining, and
resolution, applied to a student academic advisory use case.

No database, no API keys, and no internet connection are required.

## Quick Start (Windows / PowerShell)

1. Extract the ZIP file.
2. Open PowerShell in the extracted project folder.
3. Run:
   ```
   pip install -r requirements.txt
   ```
4. Run:
   ```
   python app.py
   ```
5. Open your browser at:
   ```
   http://127.0.0.1:5000
   ```

Alternatively, just double-click **run.bat** — it will create a virtual
environment (if needed), install requirements, and start the server
automatically.

## Project Structure

```
student_academic_advisory_agent/
│
├── app.py                     # Flask routes + JSON API
├── requirements.txt
├── README.md
├── run.bat
│
├── logic/                     # All FOL knowledge + reasoning code
│   ├── __init__.py
│   ├── knowledge_base.py      # Raw student data + grounded FOL facts
│   ├── rules.py                # FOL rule base (>= 6 rules, 2+ variables)
│   ├── unification.py          # Unification engine + demonstration
│   ├── forward_chaining.py     # Forward chaining engine
│   ├── backward_chaining.py    # Backward chaining engine
│   └── resolution.py           # Resolution refutation demonstration
│
├── templates/                  # HTML pages (Jinja2)
│   ├── base.html
│   ├── index.html               (Dashboard)
│   ├── advisory.html            (Student Advisory)
│   ├── knowledge.html           (Knowledge Base)
│   ├── rules.html               (FOL Rules + Quantifiers)
│   ├── queries.html             (Query System)
│   ├── unification.html
│   ├── forward.html
│   ├── backward.html
│   ├── resolution.html
│   └── comparison.html          (FOL vs Propositional Logic + Discussion)
│
└── static/
    ├── style.css
    └── script.js
```

## How the FOL Concepts Map to the Code

| Assignment requirement            | Where it lives                                         |
|-----------------------------------|----------------------------------------------------------|
| Facts (>= 8)                      | `logic/knowledge_base.py` (`ALL_FACTS`), shown on `/knowledge` |
| FOL rules (>= 6), 2+ variables    | `logic/rules.py` (`RULES`), shown on `/rules`            |
| Universal / Existential quantifiers | `/rules` page (evaluated live against the knowledge base) |
| Logical queries requiring inference | `/queries` page, `api_query()` in `app.py`              |
| Unification with substitutions    | `logic/unification.py`, shown on `/unification`          |
| Forward chaining                  | `logic/forward_chaining.py`, shown on `/forward`          |
| Backward chaining                 | `logic/backward_chaining.py`, shown on `/backward`         |
| Resolution                        | `logic/resolution.py`, shown on `/resolution`             |
| FOL vs Propositional Logic        | `/comparison` page                                        |
| Advantages / limitations / extensions | `/comparison` page (Discussion section)               |

Nothing is hard-coded per student name: every recommendation and query
answer is derived at request time by actually running the reasoning
engines over the facts in `knowledge_base.py`.

## Notes for Viva

- Facts are Python tuples, e.g. `('lowMark', 'Alice', 'Mathematics')` which
  prints as `LowMark(Alice, Mathematics)`.
- Variables in rule patterns are the single uppercase tokens `X`, `S`
  (see `logic/unification.py -> VARIABLES`).
- Forward chaining repeatedly applies all rules until no new facts appear
  (fixed point) — see `run_forward_chaining()`.
- Backward chaining recursively tries to prove a goal's supporting rule
  premises, falling back to searching known facts for existential
  variables — see `prove()` in `backward_chaining.py`.
- The resolution page shows a refutation proof: negate the goal, resolve
  with the rule's clause form, then resolve with the matching fact to
  reach the empty clause (contradiction), proving the goal true.
