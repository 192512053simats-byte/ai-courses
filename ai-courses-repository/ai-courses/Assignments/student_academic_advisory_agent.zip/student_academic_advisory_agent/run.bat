@echo off
echo ============================================
echo Intelligent Student Academic Advisory Agent
echo ============================================

if not exist venv (
    echo Creating virtual environment...
    python -m venv venv
)

echo Activating virtual environment...
call venv\Scripts\activate.bat

echo Installing requirements...
pip install -r requirements.txt

echo Starting Flask application...
echo Open http://127.0.0.1:5000 in your browser once the server starts.
python app.py

pause
