// script.js - shared helper functions used by every page

async function fetchJSON(url) {
    const res = await fetch(url);
    if (!res.ok) {
        const err = await res.json().catch(() => ({ error: "Request failed" }));
        throw new Error(err.error || "Request failed");
    }
    return res.json();
}

// Renders a backward-chaining / query trace (array of {depth, text, type})
// as indented, color-coded lines.
function renderTrace(trace) {
    if (!trace || trace.length === 0) {
        return "<p>No trace available.</p>";
    }
    return trace.map(step => {
        const indent = (step.depth || 0) * 22;
        const cls = `trace-${step.type || "subgoal"}`;
        return `<div class="trace-line ${cls}" style="margin-left:${indent}px">${step.text}</div>`;
    }).join("");
}
